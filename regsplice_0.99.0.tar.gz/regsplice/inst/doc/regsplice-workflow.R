## ---- echo = FALSE-------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE)

## ------------------------------------------------------------------------
# load data
file_counts <- system.file("extdata/vignette_counts.txt", package = "regsplice")
data <- read.table(file_counts, header = TRUE, sep = "\t", stringsAsFactors = FALSE)

head(data)

dim(data)

# extract counts and gene IDs from raw data
counts <- data[, 2:7]
gene <- sapply(strsplit(data$exon, ":"), function(s) s[[1]])

head(gene, 6)

# create condition vector
condition <- rep(c("untreated", "treated"), each = 3)

condition

## ------------------------------------------------------------------------
library(regsplice)

res <- regsplice(counts, gene, condition, seed = 123)

str(res)

## ------------------------------------------------------------------------
summary_table(res)

## ------------------------------------------------------------------------
library(regsplice)

Y <- prepare_data(counts, gene)

# length equals the number of genes
length(Y)

## ------------------------------------------------------------------------
Y <- filter_exons(Y)

# length equals the number of genes
length(Y)

## ------------------------------------------------------------------------
norm_factors <- run_normalization(Y)

norm_factors

## ------------------------------------------------------------------------
out_voom <- run_voom(Y, condition, norm_factors = norm_factors)

Y <- out_voom$Y
weights <- out_voom$weights

## ------------------------------------------------------------------------
# set random seed for reproducibility
seed <- 123

# fit regularized models
fit_reg <- suppressWarnings(
  fit_models_reg(Y, condition, weights, n_cores = 1, seed = seed)
)

# fit null models
fit_null <- fit_models_null(Y, condition, weights, seed = seed)

# fit full GLMs (not required if 'when_null_selected = "ones"' in next step)
fit_GLM <- fit_models_GLM(Y, condition, weights, seed = seed)

## ------------------------------------------------------------------------
res <- LR_tests(fit_reg, fit_null)

str(res)

## ------------------------------------------------------------------------
summary_table(res)

## ------------------------------------------------------------------------
summary_table(res, n = Inf)

## ------------------------------------------------------------------------
sum(res$p_adj < 0.05)

table(res$p_adj < 0.05)

## ------------------------------------------------------------------------
# load true DS status labels
file_truth <- system.file("extdata/vignette_truth.txt", package = "regsplice")
data_truth <- read.table(file_truth, header = TRUE, sep = "\t", stringsAsFactors = FALSE)

str(data_truth)

# remove genes that were filtered during regsplice analysis
data_truth <- data_truth[data_truth$gene %in% res$gene, ]

dim(data_truth)

# number of true DS genes in simulated data set
sum(data_truth$ds_status == 1)

table(data_truth$ds_status)

# contingency table comparing true and predicted DS status for each gene
# (significance threshold: FDR < 0.05)
table(true = data_truth$ds_status, predicted = res$p_adj < 0.05)

# increasing the threshold detects more genes, at the expense of more false positives
table(true = data_truth$ds_status, predicted = res$p_adj < 0.99)

## ------------------------------------------------------------------------
# gene with 3 exons
# 4 biological samples; 2 samples in each of 2 conditions
design_example <- create_design_matrix(condition = rep(c(0, 1), each = 2), n_exons = 3)

design_example

