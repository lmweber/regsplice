## ---- echo = FALSE-------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE)

## ------------------------------------------------------------------------
# load data
file_counts <- system.file("extdata/vignette_counts.txt", package = "regsplice")
data <- read.table(file_counts, header = TRUE, sep = "\t", stringsAsFactors = FALSE)

head(data)

# extract counts, gene_IDs, and n_exons
counts <- data[, 2:7]
tbl_exons <- table(sapply(strsplit(data$exon, ":"), function(s) s[[1]]))
gene_IDs <- names(tbl_exons)
n_exons <- unname(tbl_exons)

dim(counts)

length(gene_IDs)

head(gene_IDs)

length(n_exons)

sum(n_exons)

# create condition vector
condition <- rep(c("untreated", "treated"), each = 3)

condition

## ------------------------------------------------------------------------
library(regsplice)

res <- regsplice(counts, gene_IDs, n_exons, condition, seed = 123)

## ------------------------------------------------------------------------
summary_table(res)

## ------------------------------------------------------------------------
library(regsplice)

Y <- RegspliceData(counts, gene_IDs, n_exons, condition)

## ------------------------------------------------------------------------
Y <- filter_zeros(Y)

## ------------------------------------------------------------------------
Y <- filter_low_counts(Y)

## ------------------------------------------------------------------------
Y <- run_normalization(Y)

## ------------------------------------------------------------------------
Y <- run_voom(Y)

# view column meta-data including normalization factors and normalized library sizes
colData(Y)

## ------------------------------------------------------------------------
res <- initialize_results(Y)

## ------------------------------------------------------------------------
# set random seed for reproducibility
seed <- 123

# fit regularized models
res <- suppressWarnings(fit_reg_multiple(res, Y, n_cores = 1, seed = seed))

# fit null models
res <- fit_null_multiple(res, Y, seed = seed)

# fit "full" models (not required if 'when_null_selected = "ones"' in next step)
res <- fit_full_multiple(res, Y, seed = seed)

## ------------------------------------------------------------------------
res <- LR_tests(res)

## ------------------------------------------------------------------------
summary_table(res)

## ------------------------------------------------------------------------
summary_table(res, n = Inf)

## ------------------------------------------------------------------------
sum(res@p_adj < 0.05)

table(res@p_adj < 0.05)

## ------------------------------------------------------------------------
# load true DS status labels
file_truth <- system.file("extdata/vignette_truth.txt", package = "regsplice")
data_truth <- read.table(file_truth, header = TRUE, sep = "\t", stringsAsFactors = FALSE)

str(data_truth)

# remove genes that were filtered during regsplice analysis
data_truth <- data_truth[data_truth$gene %in% res@gene_IDs, ]

dim(data_truth)

length(res@gene_IDs)

# number of true DS genes in simulated data set
sum(data_truth$ds_status == 1)

table(data_truth$ds_status)

# contingency table comparing true and predicted DS status for each gene
# (significance threshold: FDR < 0.05)
table(true = data_truth$ds_status, predicted = res@p_adj < 0.05)

# increasing the threshold detects more genes, at the expense of more false positives
table(true = data_truth$ds_status, predicted = res@p_adj < 0.99)

## ------------------------------------------------------------------------
# gene with 3 exons
# 4 biological samples; 2 samples in each of 2 conditions
design_example <- create_design_matrix(condition = rep(c(0, 1), each = 2), n_exons = 3)

design_example

