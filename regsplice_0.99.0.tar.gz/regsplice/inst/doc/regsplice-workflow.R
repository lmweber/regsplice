## ---- echo = FALSE-------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE)

## ------------------------------------------------------------------------
# load data
file_counts <- system.file("extdata/vignette_counts.txt", package = "regsplice")
data <- read.table(file_counts, header = TRUE, sep = "\t", stringsAsFactors = FALSE)

head(data)

dim(data)

# extract counts and gene IDs from raw data
counts <- data[, 2:7]
gene <- sapply(strsplit(data$exon, ":"), function(s) s[[1]])

head(gene, 6)

# create condition vector
condition <- rep(c("untreated", "treated"), each = 3)

condition

## ------------------------------------------------------------------------
library(regsplice)

res <- regsplice(counts, gene, condition)

str(res)

## ------------------------------------------------------------------------
library(regsplice)

Y <- prepare_data(counts, gene)

# length equals the number of genes
length(Y)

## ------------------------------------------------------------------------
Y <- filter_exons(Y)

# length equals the number of genes
length(Y)

## ------------------------------------------------------------------------
out_voom <- voom_weights(Y, condition)

weights <- out_voom$weights

## ------------------------------------------------------------------------
# gene with 3 exons
# 4 biological samples; 2 samples in each of 2 conditions
design_example <- create_design_matrix(condition = rep(c(0, 1), each = 2), n_exons = 3)

design_example

## ------------------------------------------------------------------------
# fit regularized models
fit_reg <- suppressWarnings(fit_models_reg(Y, condition, weights, n_cores = 1))

# fit null models
fit_null <- fit_models_null(Y, condition, weights)

# fit full GLMs (not required if 'when_null_selected = "ones"' in next step)
fit_GLM <- fit_models_GLM(Y, condition, weights)

## ------------------------------------------------------------------------
res_no_wrapper <- LR_tests(fit_reg, fit_null)

str(res_no_wrapper)

## ------------------------------------------------------------------------
summary_table(res, n = 10)

## ------------------------------------------------------------------------
summary_table(res, n = Inf)

## ------------------------------------------------------------------------
sum(res$p_adj < 0.05)

table(res$p_adj < 0.05)

## ------------------------------------------------------------------------
# load true DS status labels
file_truth <- system.file("extdata/vignette_truth.txt", package = "regsplice")
data_truth <- read.table(file_truth, header = TRUE, sep = "\t", stringsAsFactors = FALSE)

str(data_truth)

# remove genes that were filtered during regsplice analysis
data_truth <- data_truth[data_truth$gene %in% res$gene, ]

dim(data_truth)

# number of true DS genes in simulated data set
sum(data_truth$ds_status == 1)

table(data_truth$ds_status)

# confusion matrix comparing true and predicted DS status for each gene
# (prediction threshold: FDR < 0.05)
table(true = data_truth$ds_status, predicted = res$p_adj < 0.05)

## ---- fig.width = 4.5, fig.height = 4.5----------------------------------
# calculate distance matrix (use transpose t() so samples are in rows)
d <- dist(t(counts))

# calculate MDS fit
fit_mds <- cmdscale(d)

# MDS plot
cols <- rep(c("red", "blue"), each = 3)
plot(fit_mds, col = cols, pch = 16, 
     cex.main = 0.8, cex.lab = 0.8, cex.axis = 0.8, 
     main = "MDS plot", xlab = "MDS_1", ylab = "MDS_2")
legend("bottomright", legend = c("untreated", "treated"), col = c("red", "blue"), 
       pch = 16, cex = 0.8)

## ---- fig.width = 5.25, fig.height = 5.5---------------------------------
suppressPackageStartupMessages(library(pheatmap))  # install from CRAN

# detected DS genes
detected_genes <- summary_table(res, n = Inf)$gene

# select data for detected DS genes (using "counts" and "gene" from beginning of workflow)
Y <- prepare_data(counts, gene)

Y <- filter_exons(Y)

Y_detected <- Y[detected_genes]

# aggregate counts to gene level
Y_gene <- lapply(Y_detected, colSums)

Y_gene <- as.data.frame(Y_gene)

Y_gene <- t(Y_gene)

Y_gene

# take log2
Y_gene <- log2(Y_gene)

# standardize (mean 0, standard deviation 1)
# (use transpose t() to keep matrix in same shape)
Y_gene <- t(scale(t(Y_gene)))

# heatmap with column annotation (using "condition" from beginning of workflow)
annot_col <- data.frame(condition, row.names = colnames(Y_gene))
pheatmap(Y_gene, annotation_col = annot_col, fontsize = 7, 
         main = "Heatmap: detected DS genes; scaled log2 counts per gene")

