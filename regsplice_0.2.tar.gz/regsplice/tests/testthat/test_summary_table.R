library(regsplice)
context("Summary table")

test_that("summary table function works correctly", {
  
  
})

