library(testthat)
library(regsplice)

test_check("regsplice")
