## ---- echo = FALSE-------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE)

## ------------------------------------------------------------------------
file_counts <- system.file("extdata/counts.txt", package = "regsplice")
data <- read.table(file_counts, header = TRUE, sep = "\t", stringsAsFactors = FALSE)

head(data)

dim(data)

# extract counts and gene IDs
counts <- data[, 2:7]
gene <- sapply(strsplit(data$exon, ":"), function(s) s[[1]])

head(gene, 6)

# create meta-data for biological samples
condition <- rep(c("untreated", "treated"), each = 3)

condition

## ------------------------------------------------------------------------
library(regsplice)

res <- regsplice(counts = counts, gene = gene, condition = condition)

str(res)

## ------------------------------------------------------------------------
library(regsplice)

Y <- prepare_data(counts = counts, gene = gene)

length(Y)

## ------------------------------------------------------------------------
# gene with 3 exons; 4 biological samples, 2 samples in each of 2 conditions
design_example <- create_design_matrix(condition = rep(c(0, 1), each = 2), n_exons = 3)

design_example

## ------------------------------------------------------------------------
# fit regularized models
fitted_models_reg <- fit_reg(Y = Y, condition = condition, n_cores = 1)

# fit GLMs
fitted_models_GLM <- fit_GLM(Y = Y, condition = condition)

# fit null models
fitted_models_null <- fit_null(Y = Y, condition = condition)

## ------------------------------------------------------------------------
# calculate likelihood ratio tests
res_no_wrapper <- LR_tests(fitted_models_reg = fitted_models_reg, 
                           fitted_models_GLM = NULL, 
                           fitted_models_null = fitted_models_null, 
                           when_null_selected = "ones")

## ------------------------------------------------------------------------
# p-values
# plot(res$p_vals[order(res$p_vals)], type = "b")

# multiple testing adjusted p-values
# plot(res$p_adj[order(res$p_adj)], type = "b")

## ------------------------------------------------------------------------
# microarrays example code

