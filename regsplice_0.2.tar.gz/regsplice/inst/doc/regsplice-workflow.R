## ---- echo = FALSE-------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE)

## ------------------------------------------------------------------------
# load data
file_counts <- system.file("extdata/vignette_counts.txt", package = "regsplice")
data <- read.table(file_counts, header = TRUE, sep = "\t", stringsAsFactors = FALSE)

head(data)

dim(data)

# extract counts and gene IDs from raw data
counts <- data[, 2:7]
gene <- sapply(strsplit(data$exon, ":"), function(s) s[[1]])

head(gene, 6)

# create condition vector
condition <- rep(c("untreated", "treated"), each = 3)

condition

## ------------------------------------------------------------------------
library(regsplice)

res <- regsplice(counts, gene, condition)

str(res)

## ------------------------------------------------------------------------
library(regsplice)

Y <- prepare_data(counts, gene)

# length is equal to the number of genes
length(Y)

## ------------------------------------------------------------------------
Y <- filter_exons(Y)

# length is equal to the number of genes
length(Y)

## ------------------------------------------------------------------------
# gene with 3 exons
# 4 biological samples; 2 samples in each of 2 conditions
design_example <- create_design_matrix(condition = rep(c(0, 1), each = 2), n_exons = 3)

design_example

## ------------------------------------------------------------------------
# fit regularized models
fit_reg  <- suppressWarnings(fit_models_reg(Y, condition, n_cores = 1))

# fit null models
fit_null <- fit_models_null(Y, condition)

# fit GLMs (not required if 'when_null_selected = "ones"' in the next step)
fit_GLM  <- fit_models_GLM(Y, condition)

## ------------------------------------------------------------------------
# calculate likelihood ratio tests
res2 <- LR_tests(fit_reg = fit_reg, 
                 fit_null = fit_null, 
                 when_null_selected = "ones")

## ------------------------------------------------------------------------
# p-values
# plot(res$p_vals[order(res$p_vals)], type = "b")

# multiple testing adjusted p-values
# plot(res$p_adj[order(res$p_adj)], type = "b")

## ------------------------------------------------------------------------
# weights example


## ------------------------------------------------------------------------
# microarrays example code

